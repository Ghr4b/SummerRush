package com.challenge.graphql.repository;

import com.challenge.graphql.model.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PostRepository extends JpaRepository<Post, Long> {
    List<Post> findByOwnerId(Long ownerId);
    void deleteById(Long id);
    void deleteById(UUID id);
    Optional<Post> findById(UUID id);
    Boolean existsById(UUID id);
}
