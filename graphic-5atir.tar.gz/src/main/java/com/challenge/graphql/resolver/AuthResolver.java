package com.challenge.graphql.resolver;

import com.challenge.graphql.model.AuthPayload;
import com.challenge.graphql.model.Post;
import com.challenge.graphql.model.User;
import com.challenge.graphql.security.JwtUtil;
import com.challenge.graphql.service.RecoveryTokenService;
import com.challenge.graphql.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Base64;
import java.util.List;


@Controller
public class AuthResolver {
    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private RecoveryTokenService recoveryTokenService;

    @MutationMapping
    public User register(@Argument String username, @Argument String password, @Argument String email) {
        return userService.registerUser(username, password, email);
    }

    @MutationMapping
    public AuthPayload login(@Argument String username, @Argument String password) {
        User user = userService.authenticateUser(username, password);
        if (user == null) {
            throw new RuntimeException("Invalid username or password");
        }
        String token = jwtUtil.generateToken(username);
        AuthPayload payload = new AuthPayload(token,user);

        return payload;
    }

    @MutationMapping
    public String logout() {
        SecurityContextHolder.clearContext();
        return "Logged out";
    }

    @QueryMapping
    public User me() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return null;
        }
        String username = auth.getName();
        return userService.findByUsername(username);
    }
    @QueryMapping
    public List<Post> posts() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return List.of();
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return List.of();
        }
        return user.getPosts(); 
    }
    @QueryMapping
    public String viewerToken(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return null;
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            return null;
        }
        return recoveryTokenService.getEncodedToken(user.getId());
    }
    @MutationMapping
    public String requestPasswordReset(@Argument String email){
        return recoveryTokenService.generateAndSendToken(email);
    }
    @MutationMapping
    public String resetPassword(@Argument String email,@Argument String password,@Argument String token){
        return userService.resetPassword(email, password, token);
    }
}
