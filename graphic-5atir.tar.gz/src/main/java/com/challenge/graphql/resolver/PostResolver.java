package com.challenge.graphql.resolver;

import com.challenge.graphql.model.Post;
import com.challenge.graphql.model.User;
import com.challenge.graphql.service.PostService;
import com.challenge.graphql.service.UserService;
import com.challenge.graphql.validation.ValidImageUrl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.UUID;

@Controller
public class PostResolver  {
    @Value("${FLAG:fl1tz}")
    private String flag;


    private final PostService postService;
    private final UserService userService;
    public PostResolver(PostService postService, UserService userService) {
        this.postService = postService;
        this.userService = userService;
    }

    @QueryMapping
    public List<Post> getallposts() {
        return postService.getAllPosts();
    }
    @QueryMapping
    public Post getpostbyid(@Argument UUID id) {
        return postService.getPostById(id).orElse(null);
    }
    @QueryMapping
    public List<Post> getpostsbyuserid(@Argument Long userId) {
        return postService.getPostsByOwnerId(userId);
    }
    @QueryMapping
    public List<Post> getfeedposts(@Argument int page,@Argument int size) {
        return postService.getFeedPosts(page, size).getContent();
    }

    @MutationMapping(name = "createpost")
        public Post createpost(@Argument String title, @Argument String content, @Argument String imageUrl) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            throw new RuntimeException("Unauthorized: You must be logged in to create a post.");
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found: " + username);
        }
        Long ownerId = user.getId();
        return postService.createPost(title, content, imageUrl, ownerId);
    }

    @MutationMapping
    public Post updatepost(@Argument UUID id, @Argument String title, @Argument String content, @Argument @ValidImageUrl String imageUrl) {    
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return null;
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found: " + username);
        }
        Long ownerId = user.getId();
        Post existingPost = postService.getPostById(id).orElseThrow(() -> new RuntimeException("Post not found with ID: " + id));
        if (!existingPost.getOwner().getId().equals(ownerId)) {
            throw new RuntimeException("You do not have permission to update this post");
        }

        if (!existingPost.getOwner().getId().equals(ownerId)) {
            throw new RuntimeException("You do not have permission to update this post");
        }
        return postService.updatePost(id, title, content, imageUrl);
    }
    @MutationMapping
    public Boolean deletepost(@Argument UUID id) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return false;
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found: " + username);
        }
        Long ownerId = user.getId();
        Post existingPost = postService.getPostById(id).orElseThrow(() -> new RuntimeException("Post not found with ID: " + id));
        if (!existingPost.getOwner().getId().equals(ownerId)) {
            throw new RuntimeException("You do not have permission to delete this post");
        }
        return postService.deletePost(id);
    }
    @QueryMapping
    public String getflag(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            return "You are not an admin";
        }
        String username = auth.getName();
        User user = userService.findByUsername(username);
        if (user == null || !user.getRole().equals("ADMIN")) {
            return "You are not an admin";        }
        return flag;
    }

}
