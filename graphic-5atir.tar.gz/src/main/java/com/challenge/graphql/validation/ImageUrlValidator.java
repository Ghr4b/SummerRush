package com.challenge.graphql.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

public class ImageUrlValidator implements ConstraintValidator<ValidImageUrl, String> {

    @Override
    public boolean isValid(String url, ConstraintValidatorContext context) {
        if (url == null || url.isEmpty()) return false;

        try {
            URI uri = URI.create(url);
            URL parsedUrl = uri.toURL();

            HttpURLConnection conn = (HttpURLConnection) parsedUrl.openConnection();
            conn.setRequestMethod("HEAD");
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            conn.setInstanceFollowRedirects(false);
            conn.connect();

            String contentType = conn.getContentType();
            return contentType != null && contentType.startsWith("image/");
        } catch (Exception e) {
            return false;
        }
    }
}
