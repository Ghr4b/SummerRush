package com.challenge.graphql.service;

import com.challenge.graphql.model.User;
import com.challenge.graphql.repository.UserRepository;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Optional;

@Service
public class RecoveryTokenService {
    private static final int RANDOM_LENGTH = 16;
    private static final DateTimeFormatter TOKEN_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyMMddHHmm");

    @Autowired
    private UserRepository userRepository;

    public String generateAndSendToken(String email) {
        try {
            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found with that email"));

            if (isRecentToken(user.getToken())) {
                return "slow down! A reset token is already set and hasn't expired";
            }

            String token = generateTimeBasedToken();
            user.setToken(token);
            userRepository.save(user);
            return "mailer service is not yet configured, contact support for reset token";

        } catch (RuntimeException e) {
            e.printStackTrace();
            return "an error occured";
        }
    }

    private boolean isRecentToken(String token) {
        if (token == null || token.length() < 10) {
            return false; 
        }
    
        String timestampPart = token.substring(0, 10);
    
        try {
            LocalDateTime tokenTime = LocalDateTime.parse(timestampPart, TOKEN_TIME_FORMATTER);
            LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
    
            return !tokenTime.isBefore(now.minusMinutes(5)); 
        } catch (Exception e) {
            return false;
        }
    }
    

    private String generateTimeBasedToken() {
        String timestamp = LocalDateTime.now(ZoneOffset.UTC).format(TOKEN_TIME_FORMATTER);
        String randomPart = RandomStringUtils.randomAlphanumeric(RANDOM_LENGTH);
        return timestamp + randomPart;
    }

    public Boolean validateToken(String encodedToken, String email) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) return false;

        String decoded;
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(encodedToken);
            decoded = new String(decodedBytes, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return false; // Invalid base64
        }

        return userOpt.map(user -> decoded.equals(user.getToken())).orElse(false);
    }
    public String getEncodedToken(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) return null;
        String token =  userOpt.get().getToken();
        return Base64.getEncoder().encodeToString(token.getBytes(StandardCharsets.UTF_8));

    }
}
