package com.challenge.graphql.service;

import com.challenge.graphql.model.Post;
import com.challenge.graphql.model.User;
import com.challenge.graphql.repository.PostRepository;
import com.challenge.graphql.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    public PostService(PostRepository postRepository, UserRepository userRepository) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    public List<Post> getAllPosts(int limit, int offset) {
        return postRepository.findAll().stream()
                .skip(offset)
                .limit(limit)
                .toList();

    }

    public Optional<Post> getPostById(UUID id) {
        return postRepository.findById(id);
    }

    public Post createPost(String title, String content, String imageUrl, Long ownerId) {
        Optional<User> userOpt = userRepository.findById(ownerId);
        if (userOpt.isEmpty()) {
            throw new RuntimeException("User not found with ID: " + ownerId);
        }

        Post post = new Post();
        post.setTitle(title);
        post.setContent(content);
        post.setImageUrl(imageUrl);
        post.setOwner(userOpt.get());

        return postRepository.save(post);
    }

    public Post updatePost(UUID postId, String title, String content, String imageUrl) {
        Post post = postRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("Post not found with ID: " + postId));

        post.setTitle(title);
        post.setContent(content);
        post.setImageUrl(imageUrl);

        return postRepository.save(post);
    }

    public boolean deletePost(UUID postId) {
        if (!postRepository.existsById(postId)) {
            return false;
        }
        postRepository.deleteById(postId);
        return true;
    }

    public List<Post> getPostsByOwnerId(Long ownerId) {
        return postRepository.findByOwnerId(ownerId);
    }

    public Page<Post> getFeedPosts(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return postRepository.findAll(pageable);
    }
}
