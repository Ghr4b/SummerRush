package com.challenge.graphql.service;

import com.challenge.graphql.model.User;
import com.challenge.graphql.repository.PostRepository;
import com.challenge.graphql.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private RecoveryTokenService recoveryTokenService;

    public User registerUser(String username, String password, String email) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setEmail(email);
        user.setRole("USER");
        return userRepository.save(user);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }
    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }
    public User authenticateUser(String username, String password) {
        User user = findByUsername(username);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }
        return null;
    }
    public String resetPassword(String email, String password, String token) {

        if (recoveryTokenService.validateToken(token, email)) {
            Optional<User> user = userRepository.findByEmail(email);
            user.get().setPassword(passwordEncoder.encode(password));
            userRepository.save(user.get());
            return "password changed successfully";
        }else{
            return "invalid reset token";
        }
    }
}
