document.addEventListener('DOMContentLoaded', function() {
    const token = localStorage.getItem('token');
    const currentPath = window.location.pathname;

    // If no token and not on login/register page, redirect to login
    if (!token && currentPath !== '/login' && currentPath !== '/register') {
        window.location.href = '/login';
    }

    // If token exists, add it to API requests
    if (token) {
        // Override fetch to include authorization header for API calls
        const originalFetch = window.fetch;
        window.fetch = function(url, options = {}) {
            // Only modify requests that go to your API endpoint
            if (typeof url === 'string' && url.startsWith('/api/')) {
                options.headers = options.headers || {};
                // Prevent double-adding Authorization
                if (!options.headers['Authorization']) {
                    options.headers['Authorization'] = 'Bearer ' + token;
                }
            }
            return originalFetch(url, options);
        };
    }
});

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    window.location.href = '/login';
}

// API Helper functions
async function apiRequest(url, options = {}) {
    const token = localStorage.getItem('token');

    const defaultHeaders = {
        'Content-Type': 'application/json'
    };

    // Only add Authorization header if token exists
    if (token) {
        defaultHeaders['Authorization'] = `Bearer ${token}`;
    }

    const mergedOptions = {
        ...options,
        headers: {
            ...defaultHeaders,
            ...(options.headers || {})
        }
    };

    try {
        const response = await fetch(url, mergedOptions);

        if (response.status === 401) {
            // Token expired or invalid
            logout();
            return null;
        }

        return response;
    } catch (error) {
        console.error('API request failed:', error);
        return null;
    }
}
