package com.challenge3.ctf.controller;

import com.challenge3.ctf.entity.User;
import com.challenge3.ctf.service.UserService;

import com.challenge3.ctf.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.servlet.NoHandlerFoundException;


@Controller
public class WebController {


    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtils jwtUtils;
    @GetMapping("/")
    public String home( @CookieValue(name = "jwtToken", required = false) String jwt) {
        if (jwt == null || !jwtUtils.validateJwtToken(jwt)) {
            return "redirect:/login";
        }
        return "redirect:/profile";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "register";
        }

        if (userService.existsByUsername(user.getUsername())) {
            model.addAttribute("error", "Username already exists!");
            return "register";
        }
        if (userService.existsByEmail(user.getEmail())) {
            model.addAttribute("error", "Email already exists!");
            return "register";
        }

        userService.save(user);
        return "redirect:/login?success";
    }
    @GetMapping("/profile")
    public String profile(Model model, HttpServletRequest request,
                         @CookieValue(name = "jwtToken", required = false) String jwt) {
        
        if (jwt == null || !jwtUtils.validateJwtToken(jwt)) {
            return "redirect:/login";
        }
    
        String username = jwtUtils.getUserNameFromJwtToken(jwt);
        User user = userService.findByUsername(username)
                              .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        
        model.addAttribute("user", user);
        model.addAttribute("os", request.getHeader("sec-ch-ua-platform"));
        return "profile";
    }
    @GetMapping("/logout")
    public String logout() {
        return "redirect:/login";
    }
    @ExceptionHandler(NoHandlerFoundException.class)
    public String handleNotFound() {
        return "404";
    }

}


  