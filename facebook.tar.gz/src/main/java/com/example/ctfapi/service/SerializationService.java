package com.example.ctfapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Base64;
@Service
public class SerializationService {
    private final LogService logService;
     @Autowired
     public SerializationService(LogService logService) {
         this.logService = logService;
     }
    public String serialize(Object object) {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final ObjectOutputStream objectOutputStream;
        try{
            objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(object);
            objectOutputStream.close();
            byte[] bytes = Base64.getEncoder().encode(byteArrayOutputStream.toByteArray()) ;
            logService.log("serialized object " + object.toString() + " at " + LocalDateTime.now());
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    public Object deserialize(String serialized) {
        try{
        byte[] bytes = Base64.getDecoder().decode(serialized);
        final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        final ObjectInputStream objectInputStream = new  ObjectInputStream(byteArrayInputStream);
        Object object = objectInputStream.readObject();
        objectInputStream.close();
        logService.log("deserialized object " + object.toString() + " at " + LocalDateTime.now());
            return object;
        }catch (IOException | ClassNotFoundException e){
            throw new RuntimeException(e);
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }
}
