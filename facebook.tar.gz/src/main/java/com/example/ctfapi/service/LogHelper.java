package com.example.ctfapi.service;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;

public class LogHelper extends LogService implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    public final String message;
    public LogHelper(String message) {
        this.message = message;
    }
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        log(this.message);
    }

}
