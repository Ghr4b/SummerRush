package com.example.ctfapi.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.nio.file.Path;

@Service
public class LogService {

    public void log(String message) {
        try {
            String cmd = String.format("echo \"%s\" >> logs/logs.txt", message);
            Runtime.getRuntime().exec(new String[]{"/bin/sh", "-c", cmd});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<String> getLogs() {
        Path logsPath = Paths.get("logs", "logs.txt"); 

        try {
            List<String> logs = Files.readAllLines(logsPath);
            return logs;
        } catch (IOException e) {
            throw new RuntimeException("Failed to read logs from: " + logsPath, e);
        }
    }

}
