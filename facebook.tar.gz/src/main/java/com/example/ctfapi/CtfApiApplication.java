package com.example.ctfapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtfApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(CtfApiApplication.class, args);
    }

}
