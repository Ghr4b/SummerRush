package com.example.ctfapi.dto;

import jakarta.validation.constraints.*;

public class RegisterDto {
    @NotBlank
    @Size(min = 6, max = 15, message = "Name should be between 6 and 15 characters")
    private String name;

    @NotBlank
    @Email
    private String email;

    @NotNull
    @Min(value = 13, message = "not safe for children")
    @Max(value = 30, message = "Boomer go watch yo kids")
    private Integer age;

    @NotBlank
    @Size(min = 8, max = 20, message = "Password must be between 8 and 20 characters")
    @Pattern(
            regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d|.*[^\\w\\s]).{8,}$",
            message = "Password must contain upper and lower case letters, and at least one digit or special character"
    )
    private String password;

    // Getters and Setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}