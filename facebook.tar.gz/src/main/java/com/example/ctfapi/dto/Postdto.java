package com.example.ctfapi.dto;

import jakarta.validation.constraints.*;


public class Postdto {
    @NotBlank
    @Size(min = 5, max = 10, message = "title should be between 5 and 10 characters")
    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "title must not contain special characters")
    private String title;

    @NotBlank
    @Size(min = 6, max = 35, message = "content should be between 6 and 35 characters")
    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "content must not contain special characters")
    private String content;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;

    }
    public void setContent(String content) {
        this.content = content;
    }
}
