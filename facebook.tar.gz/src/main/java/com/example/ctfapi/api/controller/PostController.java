package com.example.ctfapi.api.controller;

import com.example.ctfapi.api.model.Post;
import com.example.ctfapi.api.util.JwtUtil;
import com.example.ctfapi.dto.Postdto;
import com.example.ctfapi.exception.DuplicatePostException;
import com.example.ctfapi.repository.PostRepository;
import com.example.ctfapi.service.LogService;
import com.example.ctfapi.service.PostService;
import com.example.ctfapi.service.SerializationService;
import io.jsonwebtoken.security.SignatureException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final PostRepository postRepository;
    private final PostService postService;
    private final SerializationService serializationService;
    private final LogService logService;
    @Autowired
    public PostController(PostRepository postRepository, PostService postService, SerializationService serializationService, LogService logService) {
        this.postRepository = postRepository;
        this.postService = postService;
        this.serializationService = serializationService;
        this.logService = logService;
    }

    // Create a new post
    @PostMapping("/create")
    public ResponseEntity<?> createPost(@CookieValue(value = "jwt", required = false) String jwt,
                                        @RequestBody @Valid Postdto dto) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        try {
            Post post = new Post();
            post.setTitle(dto.getTitle());
            post.setContent(dto.getContent());
            post.setUserid(JwtUtil.extractUserId(jwt));
            postRepository.save(post);
            return ResponseEntity.ok("Post created successfully!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error creating post: " + e.getMessage());
        }
    }

    // Delete a post by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deletePost(@PathVariable("id") Long id,
                                        @CookieValue(value = "jwt", required = false) String jwt) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        try {
            Long userid = JwtUtil.extractUserId(jwt);
            Optional<Post> postOpt = postRepository.findById(id);
            if (postOpt.isPresent()) {
                Post post = postOpt.get();
                if (post.getUserid().equals(userid)) {
                    postRepository.deleteById(id);
                    return ResponseEntity.ok("Post deleted successfully!");
                } else {
                    return ResponseEntity.status(401).body(Map.of("error", "Nuh UH"));
                }
            } else {
                return ResponseEntity.status(404).body("No post found with id: " + id);
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error deleting post: " + e.getMessage());
        }
    }

    // Backup a post (serialize to bytes)
    @PostMapping("/backup")
    public ResponseEntity<?> backup(@RequestParam Long id, @CookieValue(value="jwt", required = false) String jwt ) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        Optional<Post> postOpt = postRepository.findById(id);
        if (postOpt.isEmpty()) {
            return ResponseEntity.status(404).body("No post found with id: " + id);
        }

        try {
            if (!postOpt.get().getUserid().equals(JwtUtil.extractUserId(jwt))) {
                return ResponseEntity.status(401).body(Map.of("error", "Nuh UH"));
            }
            return ResponseEntity.ok(serializationService.serialize(postOpt.get()));
        }catch (SignatureException e){
            return ResponseEntity.status(401).body(Map.of("error", "Invalid signature"));
        }
        catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error backing up post: " + e.getMessage());
        }
    }

    // Restore a post from backup
    @PostMapping("/restore")
    public ResponseEntity<String> restore(@RequestBody String base64, @CookieValue(value="jwt", required = false) String jwt ) {
        if(jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body("not logged in");
        }
        if (base64 == null || base64.isEmpty()) {
            return ResponseEntity.badRequest().body("request body is empty");
        }
        try {
           Object deserialized = serializationService.deserialize(base64);
           Post post = (Post) deserialized;
           deserialized = null;
            if (postRepository.existsById(post.getId())) {
                post = null;
                throw new DuplicatePostException("Post with this id already exists!");
            }
            post.setId(null);
            postRepository.save(post);
            return ResponseEntity.ok("Post restored successfully!");
        }
        catch (DuplicatePostException e){
            return  ResponseEntity.badRequest().body(e.getMessage());
        }
        catch (Exception e) {
            return ResponseEntity.badRequest().body("Error restoring post: " + e.getMessage());
        }
    }

    // Get all posts
    @GetMapping("/all")
    public ResponseEntity<?> getAllPosts(@CookieValue(value="jwt",required = false) String jwt) {
        if (jwt == null || jwt.isEmpty() ) {
            return ResponseEntity.status(403).body("not logged in ");
        }
        return ResponseEntity.ok(postRepository.findAll());
    }
    @GetMapping("/logs")
    public ResponseEntity<?> getAllLogs(@CookieValue(value="jwt",required = false) String jwt) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(403).body("not logged in");
        }
        if(!JwtUtil.extractUserRole(jwt).equals("ADMIN")){
            return ResponseEntity.status(403).body("not amdin");
        }
        try{
             logService.getLogs();
             return ResponseEntity.ok(logService.getLogs());
        }catch(RuntimeException e){
            return ResponseEntity.status(500).body("internal server error");
        }
    }

}
