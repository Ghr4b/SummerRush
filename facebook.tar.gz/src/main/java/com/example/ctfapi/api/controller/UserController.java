package com.example.ctfapi.api.controller;

import com.example.ctfapi.api.model.Users;
import com.example.ctfapi.api.util.JwtUtil;
import com.example.ctfapi.dto.RegisterDto;
import com.example.ctfapi.service.UserService;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@RateLimiter(name = "basicService")
public class UserController {

    @Autowired
    private UserService userService;
    @PostMapping("/all")
    public ResponseEntity<?> getUsers(@CookieValue(value = "jwt", required = false) String jwt) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        try{
            String role = JwtUtil.extractUserRole(jwt);
            if (!"ADMIN".equals(role)) {
                return ResponseEntity.status(403).body(Map.of("error", "can't access this endpoint"));
            }
            List<Users> users = userService.getAllUsers();
            return ResponseEntity.ok(Map.of("users", users));
        }catch (Exception e){
            return ResponseEntity.status(401).body(Map.of("error", "Invalid or expired token"));
        }

    }
    @PostMapping("/me")
    public ResponseEntity<?> getUserInfo(@CookieValue(value = "jwt", required = false) String jwt,HttpServletResponse response) {
        if (jwt == null || jwt.isEmpty()) {
            return  ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        try{
            Long userid = JwtUtil.extractUserId(jwt);
            Optional<Users> user = userService.getUserById(userid);
            return ResponseEntity.ok(Map.of("user", user));
        }catch (Exception e){
            return ResponseEntity.status(401).body(Map.of("error", "Invalid or expired token"));
        }

    }
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody @Valid RegisterDto dto) {

        Optional<Users> existing = userService.getUserByEmail(dto.getEmail());
        if (existing.isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Email already in use"));
        }
        Users user = new Users();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        user.setRole("USER");
//        return userService.createUser(user)
        Users created = userService.createUser(user);
        return ResponseEntity.ok(Map.of("message", "User registered", "user", created));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> loginData, HttpServletResponse response) {
        String email = loginData.get("email");
        String password = loginData.get("password");
        Optional<Users> userOpt = userService.getUserByEmail(email);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            Users user = userOpt.get();
            String role = user.getRole();
            String token = JwtUtil.generateToken(user.getId(), role);

            // Set HttpOnly cookie
            jakarta.servlet.http.Cookie cookie = new jakarta.servlet.http.Cookie("jwt", token);
            cookie.setHttpOnly(true);
            cookie.setPath("/");
            cookie.setMaxAge(86400); // 1 day
            response.addCookie(cookie);

            return ResponseEntity.ok(Map.of("message", "Login successful"));
        }
        return ResponseEntity.status(401).body(Map.of("error", "Invalid credentials"));
    }

    // LOGOUT (just invalidates the session)
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletResponse response) {
        jakarta.servlet.http.Cookie jwtCookie = new jakarta.servlet.http.Cookie("jwt", "");
        jwtCookie.setHttpOnly(true);
        jwtCookie.setPath("/");
        jwtCookie.setMaxAge(0); // Delete immediately
        // jwtCookie.setSecure(true); // Uncomment if using HTTPS
        response.addCookie(jwtCookie);

        return ResponseEntity.ok(Map.of("message", "Logout successful"));
    }

    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteAccount(
            @CookieValue(value = "jwt", required = false) String jwt,
            HttpServletResponse response
    ) {
        if (jwt == null || jwt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("error", "Not logged in"));
        }
        try {
            Long userId = JwtUtil.extractUserId(jwt);
            userService.deleteUser(userId);

            // Invalidate the cookie
            jakarta.servlet.http.Cookie jwtCookie = new jakarta.servlet.http.Cookie("jwt", "");
            jwtCookie.setHttpOnly(true);
            jwtCookie.setPath("/");
            jwtCookie.setMaxAge(0);
            response.addCookie(jwtCookie);

            return ResponseEntity.ok(Map.of("message", "Account deleted"));
        } catch (Exception e) {
            return ResponseEntity.status(401).body(Map.of("error", "Invalid or expired token"));
        }
    }
}
