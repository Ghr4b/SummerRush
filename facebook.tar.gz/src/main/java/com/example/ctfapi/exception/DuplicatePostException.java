package com.example.ctfapi.exception;


public class DuplicatePostException extends Exception {
    public DuplicatePostException(String message) {
        super(message);
    }
}