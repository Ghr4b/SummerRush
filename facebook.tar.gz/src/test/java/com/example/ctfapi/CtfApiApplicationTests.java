package com.example.ctfapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtfApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
